#!/bin/bash

# =====================================================================
# OBTENER EL DIRECTORIO REAL DEL SCRIPT (Ruta Absoluta)
# =====================================================================
DIR_PROYECTO="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Definir rutas base para plantillas y despliegues de clústeres
DIR_TEMPLATES="${DIR_PROYECTO}/templates"
DIR_CLUSTERS="${DIR_PROYECTO}/clusters"

# Mostrar ayuda en caso de error o uso incorrecto
mostrar_ayuda() {
    echo "Uso: $0 <comando> [opciones]"
    echo ""
    echo "Comandos obligatorios:"
    echo "  build               Genera los archivos del clúster y construye las imágenes de Docker."
    echo "                      (Falla si el clúster ya está arrancado)."
    echo "  start               Levanta el clúster. Si no está construido, realiza el build automáticamente."
    echo "                      (Falla si el clúster ya está arrancado)."
    echo "  stop                Detiene y destruye los contenedores del clúster."
    echo "                      (Falla si el clúster no está arrancado)."
    echo ""
    echo "Opciones opcionales:"
    echo "  -p <cluster_name>   Nombre del clúster/proyecto (Válido para todos los comandos. Por defecto: cl)"
    echo ""
    echo "Opciones opcionales (Solo válidas con el comando 'build'):"
    echo "  -n <num_nodes>      Número de nodos en el clúster (Por defecto: 3)"
    echo "  -c <cpus_per_node>  Número de cores por nodo para Slurm (Por defecto: 1)"
    echo ""
    echo "Ejemplos:"
    echo "  $0 build -n 4 -c 2 -p mi_cluster"
    echo "  $0 start -p mi_cluster"
    echo "  $0 stop -p mi_cluster"
    exit 1
}

# 1. VALIDACIÓN DEL COMANDO OBLIGATORIO
if [ $# -lt 1 ]; then
    mostrar_ayuda
fi

COMANDO=$1
shift

# Validar comando
if [ "$COMANDO" != "start" ] && [ "$COMANDO" != "stop" ] && [ "$COMANDO" != "build" ]; then
    echo "❌ Error: Comando '$COMANDO' no reconocido."
    mostrar_ayuda
fi

# Valores por defecto
NUM_NODES=3
CPUS_PER_NODE=3
CLUSTER_NAME="cl"

# 2. PROCESAMIENTO DE LOS FLAGS OPCIONALES
while getopts "n:c:p:" opt; do
  case ${opt} in
    n )
      if [ "$COMANDO" = "build" ]; then
        NUM_NODES=$OPTARG
      else
        mostrar_ayuda
      fi
      ;;
    c )
      if [ "$COMANDO" = "build" ]; then
        CPUS_PER_NODE=$OPTARG
      else
        mostrar_ayuda
      fi
      ;;
    p )
      CLUSTER_NAME=$OPTARG
      ;;
    \? )
      mostrar_ayuda
      ;;
  esac
done
# 2. PROCESAMIENTO DE LOS FLAGS OPCIONALES
while getopts "n:c:p:" opt; do
  case ${opt} in
    n ) NUM_NODES=$OPTARG ;;
    c ) CPUS_PER_NODE=$OPTARG ;;
    p ) CLUSTER_NAME=$OPTARG ;;
    \? ) mostrar_ayuda ;;
  esac
done

# Normalizar nombre del clúster
CLUSTER_NAME=$(echo "$CLUSTER_NAME" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9_-]//g')

# Directorio de este clúster específico y sus archivos
DIR_ESTE_CLUSTER="${DIR_CLUSTERS}/${CLUSTER_NAME}"
COMPOSE_FILE="${DIR_ESTE_CLUSTER}/docker-compose.yml"
SLURM_FILE="${DIR_ESTE_CLUSTER}/slurm.conf"
SHARED_DIR="${DIR_ESTE_CLUSTER}/shared-data"
EXTRA_DIR="${DIR_ESTE_CLUSTER}/extra-data"
ENTRYPOINT_FILE="${DIR_ESTE_CLUSTER}/entrypoint.sh"
DOCKERFILE_FILE="${DIR_ESTE_CLUSTER}/Dockerfile"

# 3. DETECCIÓN DE ESTADOS DEL CLÚSTER
ESTA_CONSTRUIDO=false
if [ -f "$COMPOSE_FILE" ] && [ -f "$SLURM_FILE" ] && [ -f "$ENTRYPOINT_FILE" ] && [ -f "$DOCKERFILE_FILE" ]; then
    ESTA_CONSTRUIDO=true
fi

ESTA_ARRANCADO=false
if [ "$ESTA_CONSTRUIDO" = true ]; then
    CONTE_ACTIVOS=$(docker compose -p "$CLUSTER_NAME" -f "$COMPOSE_FILE" ps --format json 2>/dev/null | grep -v "\[\]")
    if [ -n "$CONTE_ACTIVOS" ]; then
        ESTA_ARRANCADO=true
    fi
fi


# 4. FUNCIÓN INTERNA DE CONSTRUCCIÓN (BUILD)
ejecutar_build() {
    # Asegurar la existencia de las carpetas necesarias
    mkdir -p "$DIR_ESTE_CLUSTER"

    # copiar el directorio extra-data
    if [ ! -d "$EXTRA_DIR" ]; then
        echo "📁 Copiando directorio de datos extra-data: $EXTRA_DIR..."
        cp -a ${DIR_TEMPLATES}/extra-data $EXTRA_DIR
    fi

    # crear elñ directorio shared y descomprimir el tutorial
    if [ ! -d "$SHARED_DIR" ]; then
        echo "📁 Creando directorio de datos compartidos: $SHARED_DIR..."
        mkdir -p "$SHARED_DIR"
        cd "$SHARED_DIR"
        tar zxvf ${DIR_TEMPLATES}/extra-data/tutorial_bin.tgz
    fi

    # Generar un prefijo de subred único basado en el nombre del clúster
    HASH_VAL=$(echo -n "$CLUSTER_NAME" | cksum | cut -d' ' -f1)
    SUBNET_X=$(( (HASH_VAL % 240) + 10 )) 
    SUBNET_PREFIX="10.${SUBNET_X}.0"

    echo "⚙️ Construyendo configuración para el clúster '$CLUSTER_NAME' en '$DIR_ESTE_CLUSTER'..."

    # Verificar que las plantillas existen en el directorio "templates"
    if [ ! -f "${DIR_TEMPLATES}/compose_master.tmpl" ] || \
       [ ! -f "${DIR_TEMPLATES}/compose_node.tmpl" ] || \
       [ ! -f "${DIR_TEMPLATES}/compose_networks.tmpl" ] || \
       [ ! -f "${DIR_TEMPLATES}/slurm.conf.tmpl" ]; then
        echo "❌ Error: No se encontraron las plantillas (.tmpl) en '${DIR_TEMPLATES}'."
        exit 1
    fi

    # Generar docker-compose.yml en el directorio del clúster.
    # Como docker-compose.yml ahora vive dentro de clusters/<name>/, cualquier montaje que antes
    # apuntara a './shared-data-...' ahora debe apuntar de manera relativa a './shared-data' o 'slurm.conf'
    # ya que se encuentran en su mismo directorio. El contexto de compilación (build) debe subir dos niveles hasta $DIR_PROYECTO.
            
    # 1. Procesamos la plantilla Master
    sed -e "s/__CLUSTER_NAME__/${CLUSTER_NAME}/g" \
        -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" \
        -e "s|\./shared-data-${CLUSTER_NAME}|\./shared-data|g" \
        -e "s|\./slurm-${CLUSTER_NAME}\.conf|\./slurm\.conf|g" \
        "${DIR_TEMPLATES}/compose_master.tmpl" > "$COMPOSE_FILE"

    # 2. Procesamos y concatenamos los Nodos
    for (( i=2; i<=$NUM_NODES; i++ ))
    do
        NODE_ID=$((i))   
        NODE_NAME=$i       
        IP_ADDR=$(( $i + 10 ))

        sed -e "s/__ID__/${NODE_ID}/g" \
            -e "s/__NAME__/${NODE_NAME}/g" \
            -e "s/__IP__/${IP_ADDR}/g" \
            -e "s/__CLUSTER_NAME__/${CLUSTER_NAME}/g" \
            -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" \
            -e "s|\./shared-data-${CLUSTER_NAME}|\./shared-data|g" \
            -e "s|\./slurm-${CLUSTER_NAME}\.conf|\./slurm\.conf|g" \
            "${DIR_TEMPLATES}/compose_node.tmpl" >> "$COMPOSE_FILE"
    done

    # 3. Concatenamos la Red
    echo "" >> "$COMPOSE_FILE"
    sed -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" "${DIR_TEMPLATES}/compose_networks.tmpl" >> "$COMPOSE_FILE"

    # Generar slurm.conf en el directorio del clúster
    sed -e "s/__CLUSTER_NAME__/${CLUSTER_NAME}/g" \
        -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" "${DIR_TEMPLATES}/slurm.conf.tmpl" > "$SLURM_FILE"

    echo "" >> "$SLURM_FILE"

    NODES_LIST=""
    for (( i=1; i<=$NUM_NODES; i++ ))
    do
        IP_ADDR=$(( $i + 10 ))
        echo "NodeName=${CLUSTER_NAME}-node${i} NodeAddr=${SUBNET_PREFIX}.${IP_ADDR} CPUs=${CPUS_PER_NODE} State=UNKNOWN" >> "$SLURM_FILE"
        if [ -z "$NODES_LIST" ]; then
            NODES_LIST="${CLUSTER_NAME}-node${i}"
        else
            NODES_LIST="${NODES_LIST},${CLUSTER_NAME}-node${i}"
        fi
    done

    echo "" >> "$SLURM_FILE"
    echo "PartitionName=debug Nodes=${NODES_LIST} Default=YES MaxTime=INFINITE State=UP" >> "$SLURM_FILE"

    # Procesamos la plantilla entrypoint
    sed -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" \
        -e "s/__NUMBER_NODES__/${NUM_NODES}/g" \
        "${DIR_TEMPLATES}/entrypoint.tmpl" > "$ENTRYPOINT_FILE"

    # Procesamos la plantilla Dockerfile
    sed -e "s/__SUBNET_PREFIX__/${SUBNET_PREFIX}/g" \
        "${DIR_TEMPLATES}/Dockerfile.tmpl" > "$DOCKERFILE_FILE"

    # Construir imágenes de Docker apuntando al archivo final de este clúster
    echo "📦 Compilando imágenes de Docker en segundo plano..."
    docker compose -p "$CLUSTER_NAME" -f "$COMPOSE_FILE" build
}


# 5. EJECUCIÓN DE LA LÓGICA DE CADA COMANDO

# =====================================================================
# COMANDO: BUILD
# =====================================================================
if [ "$COMANDO" = "build" ]; then
    if [ "$ESTA_ARRANCADO" = true ]; then
        echo "❌ Error: El clúster '$CLUSTER_NAME' ya está arrancado y en ejecución."
        echo "   Para reconstruirlo, primero debes detenerlo ejecutando: $0 stop -p $CLUSTER_NAME"
        exit 1
    fi

    ejecutar_build

    echo "=================================================="
    echo " ✅ Clúster '$CLUSTER_NAME' construido con éxito."
    echo " Archivos generados en: $DIR_ESTE_CLUSTER"
    echo " Ya puedes arrancarlo con: $0 start -p $CLUSTER_NAME"
    echo "=================================================="
fi

# =====================================================================
# COMANDO: START
# =====================================================================
if [ "$COMANDO" = "start" ]; then
    if [ "$ESTA_ARRANCADO" = true ]; then
        echo "❌ Error: El clúster '$CLUSTER_NAME' ya se encuentra activo y arrancado."
        exit 1
    fi

    # Si NO está construido, ejecutamos el build automáticamente primero
    if [ "$ESTA_CONSTRUIDO" = false ]; then
        echo "❌ Error: El clúster '$CLUSTER_NAME' no está construido."
        exit 1
    fi

    # Doble check de seguridad por si acaso
    if [ ! -d "$SHARED_DIR" ]; then
        mkdir -p "$SHARED_DIR"
    fi

    echo "🚀 Arrancando contenedores del clúster '$CLUSTER_NAME'..."
    docker compose -p "$CLUSTER_NAME" -f "$COMPOSE_FILE" up -d

    echo "=================================================="
    echo " ¡Clúster '$CLUSTER_NAME' iniciado correctamente!"
    echo " Accede al nodo maestro con:"
    echo "   docker exec -it -u mpiuser ${CLUSTER_NAME}-node1 /bin/bash"
    echo "=================================================="
fi

# =====================================================================
# COMANDO: STOP
# =====================================================================
if [ "$COMANDO" = "stop" ]; then
    if [ "$ESTA_ARRANCADO" = false ]; then
        echo "❌ Error: El clúster '$CLUSTER_NAME' no está arrancado (no hay contenedores activos)."
        exit 1
    fi

    echo "🛑 Deteniendo y eliminando contenedores del clúster '$CLUSTER_NAME'..."
    docker compose -p "$CLUSTER_NAME" -f "$COMPOSE_FILE" down -v

    echo "=================================================="
    echo " ✅ Clúster '$CLUSTER_NAME' detenido y limpiado."
    echo "=================================================="
fi
