# MPI & Slurm Cluster (Ubuntu 26.04) on Docker

This project sets up a cluster of **X interconnected and preconfigured nodes**, ideal for learning, developing, and testing High-Performance Computing (HPC) applications using **C/C++**, **OpenMPI**, **MPICH**, and the **Slurm** workload manager.

## Cluster Architecture

*   **`<cluster>-node1` (IP: `10.Y.0.11`):** Master node coordinating the cluster (runs `slurmctld` and `slurmd`).
*   **`<cluster>-node2` (IP: `10.Y.0.12`):** Compute worker node 1 (runs `slurmd`).
*   **`<cluster>-nodeX` (IP: `10.Y.0.1X`):** Compute worker node X (runs `slurmd`).
*   **Shared Volume:** All nodes share the `/home/mpiuser/shared_data` folder in real time. Anything compiled on the master node will be immediately available on the worker nodes.
*   **Passwordless SSH:** Automatically configured for user `mpiuser` across all nodes.

---

## Cluster Management with `launch_cluster.sh`

The project includes the `launch_cluster.sh` script, which completely automates the creation and management of Docker clusters.

### Features
* Automatic generation of all configuration files from templates.
* Automatic building of the Docker image.
* Creation of an independent directory for each cluster.
* Support for multiple simultaneous clusters with different names.
* Automatic assignment of a unique Docker subnet to prevent inter-cluster network conflicts.
* Dynamic configuration of the number of nodes and CPUs per node.
* Pre-execution cluster status check before running any operation.

### Available Commands

#### Build the Cluster
Generates all configuration files and builds the Docker image.
```bash
./launch_cluster.sh build
```

#### Start the Cluster
If the cluster has not been built yet, the script automatically executes the build process before starting it.
```bash
./launch_cluster.sh start
```

#### Stop the Cluster
Stops and removes all cluster containers.
```bash
./launch_cluster.sh stop
```

### Options

All operations accept the following parameters:

| Option | Description | Default Value |
| :--- | :--- | :--- |
| `-n` | Number of nodes in the cluster | `3` |
| `-c` | CPUs assigned to each node | `3` |
| `-p` | Cluster name | `cluster` |

**Example:**

```bash
./launch_cluster.sh start -n 5 -c 4 -p laboratory
```

This command creates a cluster named `laboratory`, consisting of five nodes with four CPUs allocated to each.

---

## Project Structure

Each generated cluster has its own dedicated directory located at:

```bash
clusters/
└── <cluster_name>/
    ├── Dockerfile
    ├── docker-compose.yml
    ├── entrypoint.sh
    ├── slurm.conf
    └── shared-data/
```

This layout allows you to maintain multiple independent clusters without configuration interference.

---

## Compilation and Execution (C/C++ and MPI)

Once logged into the master node as `mpiuser` (`docker exec -it -u mpiuser slurm-master /bin/bash`), you can use the following tools:

### Switching between OpenMPI and MPICH
The system comes with both implementations installed. To switch between them globally and automatically, run these two commands and select your preferred option:

1. **To switch execution binaries (`mpirun`, `mpiexec`):**
   ```bash
   sudo update-alternatives --config mpi
   ```
2. **To switch compilers (`mpicc`, `mpicxx`):**
   ```bash
   sudo update-alternatives --config mpic
   ```

> 💡 **Tip:** To verify which implementation is currently active, run `mpirun --version`.

---

### Direct Execution with MPI
If you want to run a program directly across the network infrastructure without submitting it to the Slurm queue:

1. **Create a test source file (`/app/hello.cpp`):**
   ```cpp
   #include <mpi.h>
   #include <iostream>

   int main(int argc, char** argv) {
       MPI_Init(&argc, &argv);
       int rank, size;
       MPI_Comm_rank(MPI_COMM_WORLD, &rank);
       MPI_Comm_size(MPI_COMM_WORLD, &size);
       std::cout << "Hello from process " << rank << " of " << size << " on " << std::getenv("HOSTNAME") << std::endl;
       MPI_Finalize();
       return 0;
   }
   ```
2. **Compile your program:**
   ```bash
   mpicxx /app/hello.cpp -o /app/hello
   ```
3. **Execute the program distributed across the cluster:**
   ```bash
   # Running 3 processes distributed across master and worker nodes
   mpirun -n 3 --host slurm-master,node1,node2 /app/hello
   ```

---

### Execution via Slurm (Workload Manager)
Slurm dynamically and intelligently manages resource allocation across the cluster.

1. **Check Slurm cluster status:**
   ```bash
   sinfo
   ```
   *(You should see `slurm-master`, `node1`, and `node2` in `idle` state, indicating they are ready).*

2. **Run an interactive task with Slurm:**
   Request Slurm to execute your MPI application using 3 tasks distributed across the default partition:
   ```bash
   srun -N 3 /app/hello
   ```

3. **Submit a Batch Job Script:**
   Create a Slurm job script (`/app/my_job.sh`):
   ```bash
   #!/bin/bash
   #SBATCH --job-name=my_mpi_test
   #SBATCH --nodes=3
   #SBATCH --tasks-per-node=1
   #SBATCH --output=/app/result_%j.log

   mpirun /app/hello
   ```
   Submit the job to the queue:
   ```bash
   sbatch /app/my_job.sh
   ```
   Monitor the queue status:
   ```bash
   squeue
   ```
   You will find the distributed processing output in the generated output file `/app/result_<JOB_ID>.log`.
