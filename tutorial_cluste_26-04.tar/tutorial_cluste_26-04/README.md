# 🚀 Clúster MPI & Slurm (Ubuntu 26.04) en Docker

Este proyecto levanta un clúster de **X nodos** interconectados y preconfigurados, ideal para aprender, desarrollar y probar aplicaciones de computación de alto rendimiento (HPC) utilizando **C/C++**, **OpenMPI**, **MPICH** y el gestor de colas **Slurm**.

## 📌 Arquitectura del Clúster

*   **`<cluster>-node1` (IP: `10.Y.0.11`):** Nodo maestro que coordina el clúster (corre `slurmctld` y `slurmd`).
*   **`<cluster>-node2` (IP: `10.Y.0.12`):** Nodo esclavo de cómputo 1 (corre `slurmd`).
*   **`<cluster>-nodeX` (IP: `10.Y.0.1X`):** Nodo esclavo de cómputo X (corre `slurmd`).
*   **Volumen compartido:** Todos los nodos comparten la carpeta `/home/mpiuser/shared_data` en tiempo real. Lo que compiles en el maestro estará disponible de inmediato en los esclavos.
*   **SSH sin contraseña:** Configurado automáticamente para el usuario `mpiuser` entre todos los nodos.

---

## 🛠️ Gestión del Clúster con launch_cluster.sh

El proyecto incorpora el script launch_cluster.sh, que automatiza completamente la creación y administración de los clústeres Docker.

### Funcionalidades
* Generación automática de todos los archivos de configuración a partir de plantillas.
* Construcción automática de la imagen Docker.
* Creación de un directorio independiente para cada clúster.
* Soporte para varios clústeres simultáneos con distintos nombres.
* Asignación automática de una subred Docker diferente para evitar conflictos entre clústeres.
* Configuración dinámica del número de nodos y de CPUs por nodo.
* Comprobación del estado del clúster antes de ejecutar cada operación.

### Comandos disponibles

#### Construir el clúster
Genera todos los archivos de configuración y construye la imagen Docker.
```bash
./launch_cluster.sh build
```
#### Arrancar el clúster
Si el clúster aún no está construido, el script ejecutará automáticamente el proceso de construcción antes de iniciarlo.
```bash
./launch_cluster.sh start
```

#### Detener el clúster
Detiene y elimina todos los contenedores del clúster.
```bash
./launch_cluster.sh stop
```

### Opciones

Todas las operaciones aceptan los siguientes parámetros:

Opción  Descripción                     Valor por defecto
-n      Número de nodos del clúster     3
-c      CPUs asignadas a cada nodo      3
-p      Nombre del clúster              cluster

Ejemplo:

```bash
./launch_cluster.sh start -n 5 -c 4 -p laboratorio
```

Este comando crea un clúster llamado laboratorio, formado por cinco nodos con cuatro CPUs cada uno.

---

## Organización del proyecto

Cada clúster generado dispone de su propio directorio dentro de:

```bash
clusters/
└── <nombre_cluster>/
    ├── Dockerfile
    ├── docker-compose.yml
    ├── entrypoint.sh
    ├── slurm.conf
    └── shared-data/
```

Esto permite mantener varios clústeres independientes sin que sus configuraciones interfieran entre sí.

---

## 💻 Compilación y Ejecución (C/C++ y MPI)

Una vez que estés dentro del nodo maestro como `mpiuser` (`docker exec -it -u mpiuser slurm-master /bin/bash`), puedes utilizar estas herramientas:

### ⚙️ Alternar entre OpenMPI y MPICH
El sistema cuenta con ambas implementaciones instaladas. Para cambiar de una a otra de forma global y automática, ejecuta estos dos comandos y elige la opción que prefieras:

1. **Para cambiar los ejecutables de ejecución (`mpirun`, `mpiexec`):**
   ```bash
   sudo update-alternatives --config mpi
   ```
2. **Para cambiar los compiladores (`mpicc`, `mpicxx`):**
   ```bash
   sudo update-alternatives --config mpic
   ```

> 💡 **Tip:** Para verificar cuál está activo, ejecuta `mpirun --version`.

---

### 🚀 Ejecución Directa con MPI
Si quieres lanzar un programa directamente usando la infraestructura de red sin pasar por la cola de Slurm:

1. **Crea un código de prueba (`/app/hola.cpp`):**
   ```cpp
   #include <mpi.h>
   #include <iostream>

   int main(int argc, char** argv) {
       MPI_Init(&argc, &argv);
       int rank, size;
       MPI_Comm_rank(MPI_COMM_WORLD, &rank);
       MPI_Comm_size(MPI_COMM_WORLD, &size);
       std::cout << "Hola desde el proceso " << rank << " de " << size << " en " << std::getenv("HOSTNAME") << std::endl;
       MPI_Finalize();
       return 0;
   }
   ```
2. **Compila tu programa:**
   ```bash
   mpicxx /app/hola.cpp -o /app/hola
   ```
3. **Ejecuta el programa distribuyéndolo en el clúster:**
   ```bash
   # Utilizando 3 procesos distribuidos en el maestro y los esclavos
   mpirun -n 3 --host slurm-master,node1,node2 /app/hola
   ```

---

### 📋 Ejecución a través de Slurm (Gestor de Colas)
Slurm se encarga de asignar de manera inteligente los recursos del clúster.

1. **Verificar el estado del clúster de Slurm:**
   ```bash
   sinfo
   ```
   *(Deberías ver `slurm-master`, `node1` y `node2` en estado `idle`, es decir, listos).*

2. **Lanzar una tarea interactiva en Slurm:**
   Pide a Slurm que ejecute tu aplicación MPI utilizando 3 tareas distribuidas en la partición por defecto:
   ```bash
   srun -N 3 /app/hola
   ```

3. **Lanzar un Job mediante script por lotes (Batch):**
   Crea un script de Slurm (`/app/mi_trabajo.sh`):
   ```bash
   #!/bin/bash
   #SBATCH --job-name=mi_prueba_mpi
   #SBATCH --nodes=3
   #SBATCH --tasks-per-node=1
   #SBATCH --output=/app/resultado_%j.log

   mpirun /app/hola
   ```
   Envía el trabajo a la cola:
   ```bash
   sbatch /app/mi_trabajo.sh
   ```
   Monitorea el estado de la cola:
   ```bash
   squeue
   ```
   Verás el resultado del procesamiento distribuido en el archivo autogenerado `/app/resultado_<JOB_ID>.log`.
